package models;

public enum Desempenho {
    A_DESEJAR ,
    BOM,
    OTIMO;    
}
